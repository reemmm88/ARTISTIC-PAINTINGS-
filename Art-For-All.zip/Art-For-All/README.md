# Art-For-All

Modern E-Commerce Store using PDO, MySQL, Ajax, jQuery, PayPal Integration
