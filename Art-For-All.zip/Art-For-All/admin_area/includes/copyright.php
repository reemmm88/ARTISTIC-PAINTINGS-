<footer class="page-footer">
  <div class="font-13">2024 © <b>AdminCAST</b> - All rights reserved.</div>
  <a class="px-4" href="http://obydullahshishir.com" target="_blank">aaaaaaa </a>
  <div class="to-top"><i class="fa fa-angle-double-up"></i></div>
</footer>