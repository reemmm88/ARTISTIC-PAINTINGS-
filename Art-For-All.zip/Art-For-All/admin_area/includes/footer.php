<!-- BEGIN PAGA BACKDROPS-->
<div class="sidenav-backdrop backdrop"></div>
<div class="preloader-backdrop">
    <div class="page-preloader">Loading</div>
</div>
<!-- END PAGA BACKDROPS-->
<!-- CORE PLUGINS-->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
<script src="./assets/js/metisMenu.min.js"></script>
<script src="./assets/js/jquery.slimscroll.min.js"></script>
<!-- PAGE LEVEL PLUGINS-->
<script src="./assets/js/Chart.min.js" type="text/javascript"></script>
<script src="./assets/js/jquery-jvectormap-2.0.3.min.js"></script>
<script src="./assets/js/jquery-jvectormap-world-mill-en.js"></script>
<script src="./assets/js/jquery-jvectormap-us-aea-en.js"></script>

<!-- Data Table Plugins-->
<script type="text/javascript" src="https://cdn.datatables.net/v/dt/dt-1.10.18/datatables.min.js"></script>
<script type="text/javascript" src="./assets/js/dataTables.bootstrap4.min.js"></script>

<script src="./assets/js/sweetalert.min.js"></script>

<!-- CORE SCRIPTS-->
<script src="./assets/js/app.min.js"></script>
<!-- PAGE LEVEL SCRIPTS-->
<script src="./assets/js/dashboard_1_demo.js"></script>



<script src="./assets/js/main.js"></script>

<!-- PAGE LEVEL SCRIPTS-->

</body>

</html>